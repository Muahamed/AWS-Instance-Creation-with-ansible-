How to use this scripts .


for collect :

ansible-playbook -i /collect eco


for cpontrol :

ansible-playbook -i /collec eco

for redis :

ansible-playbook -i /redis eco