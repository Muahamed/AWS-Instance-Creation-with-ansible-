#!/bin/bash

################################################
#                                              #
# Redis Clustering Script for a 6 node cluster #
#                                              #
################################################

#Summary: Redis Clustering script

# Configuration Variables
master1=10.0.1.66
master2=10.0.1.192
master3=10.0.1.215
slave1=10.0.1.86
slave2=10.0.1.156
slave3=10.0.1.249
port=6379

export PATH=$PATH:/opt/pace/redis/bin

PACEUSER=eco

# Ensure the script is being run by eco user

if [[ "`whoami`" != "${PACEUSER}" ]];
then
  echo "ERROR:  Current user is `whoami`.  This script must be run by \"${PACEUSER}\".";
  exit 2;
fi;

# Introduce each of the three masters to each other
redis-cli -c -h $master1 -p $port cluster meet $master2 $port
redis-cli -c -h $master1 -p $port cluster meet $master3 $port

# Create slots.  Divide 16384 by equal numbers between N masters.

for slot in {0..5460}; do redis-cli -h $master1 -p $port CLUSTER ADDSLOTS $slot; done
for slot in {5461..10922}; do redis-cli -h $master2 -p $port CLUSTER ADDSLOTS $slot; done
for slot in {10923..16383}; do redis-cli -h $master3 -p $port CLUSTER ADDSLOTS $slot; done

# Now introduce each of the slaves to any of the master nodes.

redis-cli -c -h $master1 -p $port cluster meet $slave1 $port
redis-cli -c -h $master1 -p $port cluster meet $slave2 $port
redis-cli -c -h $master1 -p $port cluster meet $slave3 $port

# Now dedicate each slave to replicate a cluster in the master

sleep 5
redis-cli -c -h $slave1 -p $port cluster replicate `redis-cli cluster nodes | grep $master2 | cut -d ' ' -f1`
echo 'Replicated Slave:' $slave1 'to Master:' $master2

sleep 5
redis-cli -c -h $slave2 -p $port cluster replicate `redis-cli cluster nodes | grep $master3 | cut -d ' ' -f1`
echo 'Replicated Slave:' $slave2 'to Master:' $master3

sleep 5
redis-cli -c -h $slave3 -p $port cluster replicate `redis-cli cluster nodes | grep $master1 | cut -d ' ' -f1`
echo 'Replicated Slave:' $slave3 'to Master:' $master1

# Check for success

sleep 5
printf "Checking number of Slave nodes..."
if [ `redis-cli cluster nodes | grep -c slave` -ne 3 ]
then
   echo "Clustering has failed.  Please contact Arris"
   exit 1;
fi
printf "ok\n\n"

sleep 5
printf "Checking number of Master nodes..."
if [ `redis-cli cluster nodes | grep -c master` -ne 3 ]
then
   echo "Clustering has failed.  Please contact Arris"
   exit 1;
fi
printf "ok\n\n"

sleep 5
printf "Checking Cluster state..."
if [ `redis-cli cluster info | grep -c "cluster_state:ok"` -ne 1 ]
then
   echo "Clustering has failed.  Please contact Arris"
   exit 1;
fi
printf "ok\n\n"

sleep 5
printf "Checking number of known cluster nodes..."
if [ `redis-cli cluster info | grep -c "cluster_known_nodes:6"` -ne 1 ]
then
   echo "Clustering has failed.  Please contact Arris"
   exit 1;
fi
printf "ok\n\n"

sleep 5
printf "Checking cluster size..."
if [ `redis-cli cluster info | grep -c "cluster_size:3"` -ne 1 ]
then
   echo "Clustering has failed.  Please contact Arris"
   exit 1;
fi
printf "ok\n\n"


echo "DONE.";

echo "";
echo "Redis has been clustered successfully.  Continue with the installation.";

echo "";

exit 0;
